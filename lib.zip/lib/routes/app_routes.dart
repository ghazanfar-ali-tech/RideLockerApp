class AppRoutes {
  static const splash = '/';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const signup = '/signup';
  static const forgotPassword = '/forgot-password';
  static const home = '/home';
  static const profile = '/profile';
  static const alerts = '/alerts';
  static const editProfile = '/edit-profile';
  static const helpSupport = '/help-support';
  static const subscription = '/subscription';
  static const appPreferences = '/app-preferences';
}